const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getScopeGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const monitoringList = document.getElementById("cropMonitoringList");

const extractNumber = (value) => {
    if (!value) return 0;
    return parseInt(String(value).replace(/[^\d]/g, "")) || 0;
};

const formatKg = (value) => {
    return value.toLocaleString() + " kg";
};

const fetchData = async (endpoint) => {

    const apiURL = `${portalURL}/o/c/${endpoint}?groupId=${groupId}&pageSize=0`;

    const response = await fetch(apiURL, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": authHeader
        }
    });

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
};

const buildCropMonitoring = async () => {

    try {

        const farmersData = await fetchData("fffarmers");
        const buyersData = await fetchData("ffbuyers");

        const farmers = farmersData.items || [];
        const buyers = buyersData.items || [];

        const readySupply = farmers
            .filter(f => f.cropStatus?.key === "readyForHarvest")
            .reduce((sum, f) =>
                sum + extractNumber(f.cropsReadyForHarvest), 0
            );

        renderMonitoring(buyers, readySupply);

    } catch (error) {
        console.error("Crop Monitoring Error:", error);
    }
};

const renderMonitoring = (buyers, readySupply) => {

    monitoringList.innerHTML = "";

    buyers.forEach(buyer => {

        const buyerName = buyer.buyerName || "Buyer";
        const demand = extractNumber(buyer.requiredQuantity);

        const gap = readySupply - demand;
        const isSurplus = gap >= 0;

        const percent =
            readySupply > 0
                ? Math.min((demand / readySupply) * 100, 100)
                : 0;

        const row = document.createElement("div");
        row.className = "cm-row";

        row.innerHTML = `
            <div class="cm-row-top">
                <div class="cm-buyer">
                    <div class="cm-dot"></div>
                    ${buyerName}
                </div>
                <div class="cm-gap">
                    ${formatKg(Math.abs(gap))}
                </div>
            </div>

            <div class="cm-bar">
                <div class="cm-bar-fill ${isSurplus ? "cm-surplus" : "cm-shortage"}"
                     style="width:${percent}%">
                </div>
            </div>

            ${
                isSurplus
                    ? `<div class="cm-surplus-badge">
                        ✓ ${formatKg(gap)} surplus
                       </div>`
                    : ""
            }
        `;

        monitoringList.appendChild(row);
    });
};

buildCropMonitoring();