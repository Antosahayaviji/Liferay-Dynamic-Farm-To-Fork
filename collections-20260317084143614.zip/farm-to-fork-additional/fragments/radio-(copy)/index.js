

window[fragmentEntryLinkNamespace + 'showSelectionMenu'] = function() {
	$("#" + fragmentEntryLinkNamespace + "object-field-select").removeClass("hide");
}

$("#" + fragmentEntryLinkNamespace + "object-field-select").on("change", function() {
	const objectFieldConfigurationLabel = "Object field";
	const label = $("label:contains('" + objectFieldConfigurationLabel + "')").filter(function() {
		return $(this).text().trim() === objectFieldConfigurationLabel;
	});
	const inputId = label.attr('for');
	const inputField = document.getElementById(inputId);
	DP4LS.Objects.Utils.setConfigurationFieldValue(inputField, $(this).val());
});

$('input[type=radio][name='+ fragmentEntryLinkNamespace +'radio-option]').on('change', function() {
  	if ($(this).is(':checked')) {
		$('#'+ fragmentEntryLinkNamespace +'radio-value').val($(this).val());
		$('#'+ fragmentEntryLinkNamespace +'radio-value').trigger("change");
	}
});

$('#' + fragmentEntryLinkNamespace + 'radio-value, #' + fragmentEntryLinkNamespace + 'radio-wrapper input.govuk-radios__input').on('blur',function(e){
	if(configuration.isRequired) {
		let value = $('#' + fragmentEntryLinkNamespace + 'radio-value').val();
		if (!value) {
			$('#' + fragmentEntryLinkNamespace + 'radio-wrapper').addClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'radio-error').removeClass('hide');
		} else {
			$('#' + fragmentEntryLinkNamespace + 'radio-wrapper').removeClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'radio-error').addClass('hide');
		}
	}
});




/* =====================================================
   SAFE HELPERS
   ===================================================== */

function byId(id) {
	return document.getElementById(id);
}

/* =====================================================
   CONFIG SELECTION MENU (SAFE)
   ===================================================== */

window[fragmentEntryLinkNamespace + 'showSelectionMenu'] = function () {
	const select = byId(fragmentEntryLinkNamespace + 'object-field-select');
	if (select) {
		select.classList.remove('hide');
	}
};

(function () {
	const select = byId(fragmentEntryLinkNamespace + 'object-field-select');
	if (!select) return;

	select.addEventListener('change', function () {

		// Guard DP4LS
		if (
			typeof DP4LS === 'undefined' ||
			!DP4LS.Objects ||
			!DP4LS.Objects.Utils
		) {
			return;
		}

		const labels = document.querySelectorAll('label');
		let targetLabel;

		labels.forEach(label => {
			if (label.textContent.trim() === 'Object field') {
				targetLabel = label;
			}
		});

		if (!targetLabel) return;

		const inputId = targetLabel.getAttribute('for');
		if (!inputId) return;

		const inputField = byId(inputId);
		if (!inputField) return;

		DP4LS.Objects.Utils.setConfigurationFieldValue(
			inputField,
			this.value
		);
	});
})();

/* =====================================================
   RADIO VALUE SYNC (NO JQUERY)
   ===================================================== */

(function () {
	const radios = document.querySelectorAll(
		'input[type="radio"][name="' + fragmentEntryLinkNamespace + 'radio-option"]'
	);

	const hidden = byId(fragmentEntryLinkNamespace + 'radio-value');
	if (!hidden) return;

	radios.forEach(radio => {
		radio.addEventListener('change', function () {
			if (this.checked) {
				hidden.value = this.value;
				hidden.dispatchEvent(new Event('change', { bubbles: true }));
			}
		});
	});
})();

/* =====================================================
   REQUIRED VALIDATION (SAFE)
   ===================================================== */

(function () {

	if (!configuration || !configuration.isRequired) return;

	const hidden = byId(fragmentEntryLinkNamespace + 'radio-value');
	const wrapper = byId(fragmentEntryLinkNamespace + 'radio-wrapper');
	const error = byId(fragmentEntryLinkNamespace + 'radio-error');

	if (!hidden || !wrapper || !error) return;

	hidden.addEventListener('blur', function () {
		if (!hidden.value) {
			wrapper.classList.add('govuk-form-group--error');
			error.classList.remove('hide');
		} else {
			wrapper.classList.remove('govuk-form-group--error');
			error.classList.add('hide');
		}
	});
})();

/* =====================================================
   ALIGNMENT FIX (NO SIDE EFFECTS)
   ===================================================== */

(function () {
	const wrapper = byId(fragmentEntryLinkNamespace + 'radio-wrapper');
	if (!wrapper) return;

	const radios = wrapper.querySelector('.govuk-radios');
	if (!radios) return;

	// Remove classes that force vertical layout
	radios.classList.remove('govuk-radios--inline');
	radios.classList.remove('pull-right');
})();
