window[fragmentEntryLinkNamespace + 'showSelectionMenu'] = function() {
	$("#" + fragmentEntryLinkNamespace + "object-field-select").removeClass("hide");
}

// =====================
// ORIGINAL CODE - DO NOT TOUCH
// =====================
$('input[type=checkbox][name='+ fragmentEntryLinkNamespace +'checkbox-option]').on('change', function() {
		var checkedValues = new Array();
		$('input[type=checkbox][name='+ fragmentEntryLinkNamespace +'checkbox-option]:checked').each(function() {
			checkedValues.push(this.value);
		});
		$('#' + fragmentEntryLinkNamespace + 'checkbox-value').val(checkedValues);
		$('#' + fragmentEntryLinkNamespace + 'checkbox-value').trigger("change");
});

Liferay.on('allPortletsReady', function () {
	
	$("#" + fragmentEntryLinkNamespace + "object-field-select").on("change", function() {
		const objectFieldConfigurationLabel = "Object field";
		const label = $("label:contains('" + objectFieldConfigurationLabel + "')").filter(function() {
			return $(this).text().trim() === objectFieldConfigurationLabel;
		});
		const inputId = label.attr('for');
		const inputField = document.getElementById(inputId);
		DP4LS.Objects.Utils.setConfigurationFieldValue(inputField, $(this).val());
	});
	
	$('[data-object-field]').on("change", function () {
		var dataObjectFields = document.querySelectorAll('[data-object-field]');
		const context = {};
		for (let dataObjectField of dataObjectFields) {
			let objectFieldName = dataObjectField.dataset.objectField;
			if (objectFieldName) {
				let objectFieldValue = dataObjectField.value;
				context[objectFieldName] = objectFieldValue.replace(/(\r\n|\n|\r)/gm, "");
			}
		}
		let hidden = false;
		if (configuration.fieldVisibility) {
			const visibilityFunction = new Function(...Object.keys(context), `return !(${configuration.fieldVisibility})`);
			hidden = visibilityFunction(...Object.values(context));
		}
		if (hidden) {
			$('#' + fragmentEntryLinkNamespace + 'checkbox-wrapper').addClass('hide');
		} else {
			$('#' + fragmentEntryLinkNamespace + 'checkbox-wrapper').removeClass('hide');
		}
	});

});

$('#' + fragmentEntryLinkNamespace + 'checkbox-value, #' + fragmentEntryLinkNamespace + 'checkbox-wrapper input.govuk-checkboxes__input').on('blur',function(e){
	if(configuration.isRequired && $(this).closest(".hide").length === 0) {
		let value = $('#' + fragmentEntryLinkNamespace + 'checkbox-value').val();
		if (!value) {
			$('#' + fragmentEntryLinkNamespace + 'checkbox-wrapper').addClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'checkbox-error').removeClass('hide');
		} else {
			$('#' + fragmentEntryLinkNamespace + 'checkbox-wrapper').removeClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'checkbox-error').addClass('hide');
		}
	}
});

// =====================
// DROPDOWN ONLY - ADD AFTER ORIGINAL
// =====================
setTimeout(function() {
	var ns = fragmentEntryLinkNamespace;
	var $wrapper = $('#' + ns + 'checkbox-wrapper');
	var $checkboxesDiv = $wrapper.find('.govuk-checkboxes');

	$checkboxesDiv.before(
		'<div class="dp-checkbox-dropdown" id="' + ns + 'dp-dropdown">' +
			'<div class="dp-checkbox-dropdown__trigger" id="' + ns + 'dp-trigger">' +
				'<span class="dp-checkbox-dropdown__text" id="' + ns + 'dp-trigger-text">Select options</span>' +
				'<span class="dp-checkbox-dropdown__arrow">&#8964;</span>' +
			'</div>' +
			'<div class="dp-checkbox-dropdown__menu hide" id="' + ns + 'dp-menu"></div>' +
		'</div>'
	);

	var $menu = $('#' + ns + 'dp-menu');
	$menu.append($checkboxesDiv);

	// Trigger text update - binds to original change event
	$('input[type=checkbox][name='+ ns +'checkbox-option]').on('change', function() {
		var checkedLabels = [];
		$('input[type=checkbox][name='+ ns +'checkbox-option]:checked').each(function() {
			checkedLabels.push($(this).closest('.govuk-checkboxes__item').find('label').text().trim());
		});
		$('#' + ns + 'dp-trigger-text').text(checkedLabels.length > 0 ? checkedLabels.join(', ') : 'Select options');
	});

	$('#' + ns + 'dp-trigger').on('click', function(e) {
		e.stopPropagation();
		$menu.toggleClass('hide');
		$(this).toggleClass('dp-open');
	});

	$(document).on('click', function(e) {
		if (!$(e.target).closest('#' + ns + 'dp-dropdown').length) {
			$menu.addClass('hide');
			$('#' + ns + 'dp-trigger').removeClass('dp-open');
		}
	});
}, 500);