const portalURL = Liferay.ThemeDisplay.getPortalURL();
const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const tradersAPI   = `${portalURL}/o/c/fftraders?pageSize=0`;
const buyersAPI    = `${portalURL}/o/c/ffbuyers?pageSize=0`;
const transportAPI = `${portalURL}/o/c/fftransports?pageSize=0`;

async function fetchData(url) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      "Authorization": authHeader
    }
  });

  if (!response.ok) {
    console.error("API Error:", url, response.status);
    return { items: [] };
  }

  return response.json();
}

function daysBetween(dateString) {
  const created = new Date(dateString);
  const now = new Date();
  const diff = now - created;
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

async function loadActivityAlerts() {

  const traders   = await fetchData(tradersAPI);
  const buyers    = await fetchData(buyersAPI);
  const transport = await fetchData(transportAPI);

  const alertList = document.getElementById("alertList");
  alertList.innerHTML = "";

  const alerts = [];

  /* Buyer Pending Orders */
  buyers.items.forEach(b => {
    if (b.orderStatus?.key === "pending") {
      alerts.push({
        type: "warning",
        title: b.buyerName,
        text: "Pending order • " + (b.requiredQuantity || "")
      });
    }
  });

  traders.items.forEach(t => {
    if (t.status?.code !== 0) {
      const days = daysBetween(t.dateCreated);
      alerts.push({
        type: "danger",
        title: t.traderName,
        text: days + " days inactive"
      });
    }
  });

  
  transport.items.forEach(tr => {
    if (tr.deliveryStatus?.key !== "onTime") {
      alerts.push({
        type: "danger",
        title: tr.transportCompanyName,
        text: "Delivery status: " + tr.deliveryStatus?.name
      });
    }
  });

  alerts.slice(0, 5).forEach(a => {

    const iconClass = a.type === "warning" ? "alert-warning" : "alert-danger";
    const iconSymbol = "!";

    const html = `
      <div class="alert-item">
        <div class="alert-icon ${iconClass}">${iconSymbol}</div>
        <div class="alert-content">
          <div class="alert-title">${a.title}</div>
          <div class="alert-text">${a.text}</div>
        </div>
      </div>
    `;

    alertList.innerHTML += html;
  });

}

loadActivityAlerts();