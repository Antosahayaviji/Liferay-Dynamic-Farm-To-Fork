function observeClassChanges(targetDiv) {
    const backLink = $(targetDiv).find(".form-container-back-link");

    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                if (backNavigationHistory.length == 0) {
                    $(backLink).addClass("hide");
                }
                else {
                    $(backLink).removeClass("hide");
                }
            }
        }
    });

    observer.observe(targetDiv, { attributes: true });
}


window[fragmentEntryLinkNamespace + "processOnclick"] = function (element, event) {
	event.preventDefault();
	
	element.disabled=true;
	
	const submitEvent = new Event("submitForm");
	element.form.dispatchEvent(submitEvent);
	
	return false;
}

observeClassChanges(document.getElementById(fragmentEntryLinkNamespace + "form-container-page"));

(function () {

    document.addEventListener("click", function (e) {
        var target = e.target;

        if (
            target &&
            target.tagName === "A" &&
            target.textContent.trim() === "Change"
        ) {
            e.preventDefault();

            var backLink = document.querySelector(".form-container-back-link");
            if (backLink) {
                backLink.click();
            }
        }
    });

})();
