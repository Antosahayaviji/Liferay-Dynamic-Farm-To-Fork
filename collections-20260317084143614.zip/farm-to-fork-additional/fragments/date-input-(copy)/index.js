window[fragmentEntryLinkNamespace + 'showSelectionMenu'] = function() {
    $("#" + fragmentEntryLinkNamespace + "object-field-select").removeClass("hide");
};

Liferay.on('allPortletsReady', function () {
    $("#" + fragmentEntryLinkNamespace + "object-field-select").on("change", function() {
        const objectFieldConfigurationLabel = "Object field";
        const label = $("label:contains('" + objectFieldConfigurationLabel + "')").filter(function() {
            return $(this).text().trim() === objectFieldConfigurationLabel;
        });
        const inputId = label.attr('for');
        const inputField = document.getElementById(inputId);
        DP4LS.Objects.Utils.setConfigurationFieldValue(inputField, $(this).val());
    });

    $('[data-object-field]').on("change", function () {
        var dataObjectFields = document.querySelectorAll('[data-object-field]');
        const context = {};
        
        for (let dataObjectField of dataObjectFields) {
            let objectFieldName = dataObjectField.dataset.objectField;
            if (objectFieldName) {
                let objectFieldNameValue = dataObjectField.value;
                context[objectFieldName] = objectFieldNameValue.replace(/(\r\n|\n|\r)/gm, "");
            }
        }

        let hidden = false;
        if (configuration.fieldVisibility) {
            const visibilityFunction = new Function(...Object.keys(context), `return !(${configuration.fieldVisibility})`);
            hidden = visibilityFunction(...Object.values(context));
        }

        if (hidden) {
            $('#' + fragmentEntryLinkNamespace + 'date-wrapper').addClass('hide');
        } else {
            $('#' + fragmentEntryLinkNamespace + 'date-wrapper').removeClass('hide');
        }
    });
});

$('#' + fragmentEntryLinkNamespace + 'date-input').on('blur change', function () {
    const value = $(this).val();
    let hasError = false;

    if (configuration.isRequired && !value) {
        hasError = true;
    }

    if (configuration.validation && !hasError) {
        let regex = RegExp(configuration.validation);
        if (value && !regex.test(value)) {
            hasError = true;
        }
    }

    if (hasError) {
        $('#' + fragmentEntryLinkNamespace + 'date-wrapper').addClass('govuk-form-group--error');
        $('#' + fragmentEntryLinkNamespace + 'date-input-error').removeClass('hide');
        $('#' + fragmentEntryLinkNamespace + 'date-input').addClass('govuk-input--error');
    } else {
        $('#' + fragmentEntryLinkNamespace + 'date-wrapper').removeClass('govuk-form-group--error');
        $('#' + fragmentEntryLinkNamespace + 'date-input-error').addClass('hide');
        $('#' + fragmentEntryLinkNamespace + 'date-input').removeClass('govuk-input--error');
    }
});



Liferay.on('allPortletsReady', function () {

    const ns = fragmentEntryLinkNamespace;
    const dateInput = document.getElementById(ns + 'date-input');
    const errorEl = document.getElementById(ns + 'date-input-error');

    if (!dateInput || !errorEl) return;

    /* Create a dedicated error container once */
    let errorHolder = document.getElementById(ns + 'date-error-holder');

    if (!errorHolder) {
        errorHolder = document.createElement('div');
        errorHolder.id = ns + 'date-error-holder';

        /* Existing styles */
        errorHolder.style.marginTop = '2px';
        errorHolder.style.color = '#d4351c'; // GOVUK error red
        errorHolder.style.fontSize = '14px';

        /* ✅ RIGHT SIDE ALIGNMENT (ONLY CHANGE) */
        errorHolder.style.display = 'flex';
        errorHolder.style.justifyContent = 'flex-end';
        errorHolder.style.width = '100%';

        dateInput.parentNode.insertBefore(
            errorHolder,
            dateInput.nextSibling
        );
    }

    /* Move error text into holder */
    errorHolder.appendChild(errorEl);

    /* Ensure it behaves like a normal block */
    errorEl.style.position = 'static';
    errorEl.style.display = 'block';
});
