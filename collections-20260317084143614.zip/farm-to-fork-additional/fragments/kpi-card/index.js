const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getScopeGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const topKpiBar = document.getElementById("topKpiBar");

const formatKg = (value) => value.toLocaleString() + " kg";

const extractNumber = (value) => {
    if (!value) return 0;
    return parseInt(String(value).replace(/[^\d]/g, "")) || 0;
};

const fetchData = async (path) => {
    const apiURL = `${portalURL}/o/c/${path}?groupId=${groupId}&pageSize=0`;

    const response = await fetch(apiURL, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": authHeader
        }
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    return response.json();
};

const buildTopKpi = async () => {

    try {

        const farmersData = await fetchData("fffarmers");
        const buyersData = await fetchData("ffbuyers");
        const transportData = await fetchData("fftransports");

        const farmers = farmersData.items || [];
        const buyers = buyersData.items || [];
        const transports = transportData.items || [];

        const totalFarmers = farmersData.totalCount || 0;
        const totalCrops = farmers.length;

        const readyCrops = farmers.filter(f =>
            f.cropStatus?.key === "readyForHarvest"
        );

        const readyQuantity = readyCrops.reduce((sum, f) =>
            sum + extractNumber(f.cropsReadyForHarvest), 0
        );

        const totalDemand = buyers.reduce((sum, b) =>
            sum + extractNumber(b.requiredQuantity), 0
        );

        const delayedCount = transports.filter(t =>
            t.status?.key === "delayed"
        ).length;

        renderTopKpi(
            totalFarmers,
            totalCrops,
            readyQuantity,
            totalDemand,
            delayedCount
        );

    } catch (error) {
        console.error("Top KPI Error:", error);
    }
};

const renderTopKpi = (farmers, crops, readyKg, demandKg, delays) => {

    topKpiBar.innerHTML = `

        <div class="kpi-item">
            <div class="kpi-icon farmers">
                <i class="fas fa-user-friends"></i>
            </div>
            <div class="kpi-content">
                <div class="kpi-title">Total Farmers</div>
                <div class="kpi-main-row">
                    <div class="kpi-value">${farmers}</div>
                </div>
            </div>
        </div>

        <div class="kpi-item">
            <div class="kpi-icon crops">
                <i class="fas fa-seedling"></i>
            </div>
            <div class="kpi-content">
                <div class="kpi-title">Crops</div>
                <div class="kpi-main-row">
                    <div class="kpi-value">${crops}</div>
                    <span class="kpi-badge-green">↑ Ready</span>
                </div>
            </div>
        </div>

        <div class="kpi-item">
            <div class="kpi-icon harvest">
                <i class="fas fa-box-open"></i>
            </div>
            <div class="kpi-content">
                <div class="kpi-title">Crops Ready for Harvest</div>
                <div class="kpi-main-row">
                    <div class="kpi-value">${formatKg(readyKg)}</div>
                </div>
            </div>
        </div>

        <div class="kpi-item">
            <div class="kpi-icon demand">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="kpi-content">
                <div class="kpi-title">Total Buyer Demand</div>
                <div class="kpi-main-row">
                    <div class="kpi-value">${formatKg(demandKg)}</div>
                    <span class="kpi-badge-red">
                        ${(demandKg - readyKg > 0) ? formatKg(demandKg - readyKg) : "0 kg"}
                    </span>
                </div>
            </div>
        </div>

        <div class="kpi-item">
            <div class="kpi-icon delay">
                <i class="fas fa-truck"></i>
            </div>
            <div class="kpi-content">
                <div class="kpi-title">Delivery Delays</div>
                <div class="kpi-main-row">
                    <div class="kpi-value">${delays}</div>
                </div>
            </div>
        </div>
    `;
};

buildTopKpi();