const portalURL = Liferay.ThemeDisplay.getPortalURL();
const friendlyURL = Liferay.ThemeDisplay.getLayoutRelativeURL();

const detectObjectFromPage = () => {

    console.log("Friendly URL:", friendlyURL);

    if (friendlyURL.includes("farmer")) return "fffarmer";
    if (friendlyURL.includes("buyer")) return "ffbuyer";
    if (friendlyURL.includes("trader")) return "fftrader";
    if (friendlyURL.includes("transport")) return "fftransport";

    return null;
};

const openForm = () => {

    const objectName = detectObjectFromPage();

    if (!objectName) {
        console.log("No object mapped to this page.");
        return;
    }

    const formURL = `${portalURL}/web/farm-to-fork/o/${objectName}`;

    console.log("Opening:", formURL);

    window.location.href = formURL;
};

Liferay.on('allPortletsReady', function() {

    const applyBtn = document.getElementById("applyBtn");

    if (!applyBtn) {
        console.log("Apply button not found.");
        return;
    }

    applyBtn.addEventListener("click", openForm);

});