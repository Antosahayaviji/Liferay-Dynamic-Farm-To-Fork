const portalURL = Liferay.ThemeDisplay.getPortalURL();
const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const tradersAPI   = `${portalURL}/o/c/fftraders?pageSize=0`;
const farmersAPI   = `${portalURL}/o/c/fffarmers?pageSize=0`;
const buyersAPI    = `${portalURL}/o/c/ffbuyers?pageSize=0`;
const transportAPI = `${portalURL}/o/c/fftransports?pageSize=0`;

async function fetchData(url) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      "Authorization": authHeader
    }
  });

  if (!response.ok) {
    console.error("API Error:", url, response.status);
    return { items: [] };
  }

  return response.json();
}

function extractNumber(value) {
  if (!value) return 0;
  const number = value.toString().replace(/[^0-9.]/g, "");
  return Number(number) || 0;
}

function normalize(text) {
  if (!text) return "";
  return text.toString().trim().toLowerCase();
}

async function loadTraderTable() {

  const traders   = await fetchData(tradersAPI);
  const farmers   = await fetchData(farmersAPI);
  const buyers    = await fetchData(buyersAPI);
  const transport = await fetchData(transportAPI);

  const tbody = document.getElementById("traderTableBody");
  tbody.innerHTML = "";

  const totalBuyerDemand = buyers.items
    .reduce((sum, b) => sum + extractNumber(b.requiredQuantity), 0);

 
  const totalTransports = transport.items.length;
  const totalOnTime = transport.items.filter(
    t => t.deliveryStatus?.key === "onTime"
  ).length;

  traders.items.forEach(trader => {

    const traderName = trader.traderName || "-";

  
    let farmerNames = [];
    if (trader.assignedFarmers) {
      farmerNames = trader.assignedFarmers
        .split(",")
        .map(f => normalize(f));
    }

    const matchedFarmers = farmers.items.filter(f =>
      farmerNames.includes(normalize(f.farmerName))
    );
    const harvestReady = matchedFarmers
      .filter(f => f.cropStatus?.key === "readyForHarvest")
      .reduce((sum, f) => sum + extractNumber(f.cropsReadyForHarvest), 0);

    const totalFarmersAssigned = matchedFarmers.length;

    let deliveryStatus = "-";
    if (totalTransports > 0) {
      deliveryStatus = totalOnTime + "/" + totalTransports + " On Time";
    }
    let performanceText = "Inactive";
    let barClass = "red-bar";
    let dotClass = "inactive-dot";
    let percent = 25;

    if (trader.status?.code === 0) {
      performanceText = "Active";
      barClass = "green-bar";
      dotClass = "active-dot";
      percent = 75;
    }

    const row = `
      <tr>
        <td><strong>${traderName}</strong></td>
        <td>${totalFarmersAssigned}</td>
        <td>${harvestReady} kg</td>
        <td>${totalBuyerDemand} kg</td>
        <td>${deliveryStatus}</td>
        <td>
          <div class="progress-bar">
            <div class="progress-fill ${barClass}" 
                 style="width:${percent}%"></div>
          </div>
          <div class="status">
            <span class="status-dot ${dotClass}"></span>
            ${performanceText}
          </div>
        </td>
      </tr>
    `;

    tbody.innerHTML += row;

  });

}

loadTraderTable();