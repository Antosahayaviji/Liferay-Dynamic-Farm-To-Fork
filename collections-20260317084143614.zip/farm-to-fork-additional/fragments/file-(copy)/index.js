let cropper;
const image = document.getElementById(fragmentEntryLinkNamespace + 'image');
const toolbar = document.getElementById(fragmentEntryLinkNamespace + 'toolbar');
const fileUpload = document.getElementById(fragmentEntryLinkNamespace + 'file-upload-data');
const fileNameDisplay = document.getElementById(fragmentEntryLinkNamespace + 'display-filename');

let storedBase64 = null;

/* ===============================
   FILE CHANGE HANDLER
================================ */
$('#' + fragmentEntryLinkNamespace + 'file-upload').on('change', async function (e) {
	if (!validateUpload(this)) {
		return;
	}

	const file = e.target.files[0];
	if (!file) return;

	/* ✅ show only filename */
	if (fileNameDisplay) {
		fileNameDisplay.textContent = file.name;
	}

	/* ✅ store filename for summary */
	fileUpload.dataset.fileName = file.name;
	fileUpload.value = file.name;

	/* ❌ HIDE IMAGE + TOOLBAR ALWAYS */
	if (image) image.classList.add('hide');
	if (toolbar) toolbar.classList.add('hide');

	/* ✅ convert to base64 silently */
	try {
		const fullBase64 = await convertBase64(file);
		storedBase64 = fullBase64.split(',')[1] || fullBase64;
	} catch (error) {
		console.error('Error converting file:', error);
		alert('Error processing file. Please try again.');
	}
});

/* ===============================
   VALIDATION (UNCHANGED)
================================ */
function validateUpload(uploadField) {
	let value = uploadField.value || "";
	let hasInputErrors = false;
	let errorMessage = "";

	if (!value) {
		hasInputErrors = true;
		errorMessage = configuration.customErrorMessage;
	}

	if (configuration.allowedFileTypes && !hasInputErrors) {
		let filename = uploadField.files[0].name;
		let type = filename.split('.').pop();
		if (!configuration.allowedFileTypes.includes(type)) {
			hasInputErrors = true;
			errorMessage = "The selected file must be a " + configuration.allowedFileTypes;
		}
	}

	if (configuration.maxFileSize && !hasInputErrors) {
		if ((uploadField.files[0].size / 1024 / 1024) > parseInt(configuration.maxFileSize)) {
			hasInputErrors = true;
			errorMessage = "The selected file must be smaller than " + configuration.maxFileSize + "MB";
		}
	}

	if (hasInputErrors) {
		$('#' + fragmentEntryLinkNamespace + 'enquiry-document-upload-wrapper')
			.addClass('govuk-form-group--error');
		$('#' + fragmentEntryLinkNamespace + 'enquiry-document-upload-error0')
			.text(errorMessage)
			.removeClass('hide');
		return false;
	}

	$('#' + fragmentEntryLinkNamespace + 'enquiry-document-upload-error0').addClass('hide');
	return true;
}

/* ===============================
   BASE64 CONVERSION
================================ */
const convertBase64 = (file) => {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = () => resolve(reader.result);
		reader.onerror = reject;
	});
};

/* ===============================
   FORM SUBMIT HANDLER (UNCHANGED)
================================ */
setTimeout(function () {
	const parentForm = fileUpload ? fileUpload.closest('form') : null;

	if (parentForm) {
		parentForm.addEventListener('submit', function (e) {
			if (storedBase64 && fileUpload.value === fileUpload.dataset.fileName) {
				e.preventDefault();
				fileUpload.value = storedBase64;

				setTimeout(function () {
					parentForm.submit();
				}, 50);
			}
		}, true);
	}
}, 500);

/* ===============================
   OBJECT FIELD NAME SET (UNCHANGED)
================================ */
const hiddenInputInit = document.getElementById(
	fragmentEntryLinkNamespace + 'file-upload-data'
);

if (
	hiddenInputInit &&
	configuration.objectField &&
	configuration.objectField.length > 0
) {
	hiddenInputInit.setAttribute('name', configuration.objectField);
}
