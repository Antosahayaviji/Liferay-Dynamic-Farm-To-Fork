window["backNavigationHistory"] = [];

const registerLiferayForm = function(formId) {
	AUI().use("liferay-form", function(){		
		Liferay.Form.register({ id: formId });
	});
}

const preventFormSubmissionOnEnterPress = function(formId) {
	$("#" + formId).on("keypress", function (event) {
		const targetType = event.target.type;
		if (event.keyCode == 13 && targetType != 'submit' && targetType != 'button' && targetType != 'file' && targetType != 'textarea') {
			event.preventDefault();
		}
	});
}

const thereAreNoHiddenErrors = function(element) {
	let erroedElements = $(element).find('.govuk-form-group--error');
	let noHiddenError = false;
	
	$(erroedElements).each(function() {
		if ($(this).parents(".hide").length == 0) {
			noHiddenError = true;
			this.scrollIntoView({ behavior: "smooth", block: "center" });
			return false;
		}
	});
	
	return noHiddenError;
}

$( "#"+ fragmentEntryLinkNamespace +"db-form-container" ).on( "submitForm", function( event ) {
	
	event.preventDefault();
	
	if (configuration.displayLoadingAnimation) {
		$("#" + fragmentEntryLinkNamespace + "loadingAnimation").removeClass("hide");
	}

	var body = {};
	$(this).find('.dp-form-condition').each(function( index ) {
		$( this ).trigger('change');
	});

	$(this).find('[data-object-field]').each(function( index ) {

		if( $( this ).parents('.hide:not(.form-container-page)').length > 0) {
			$( this ).val('');
		}

		let objectType = $( this ).attr('data-object-type');
		
		if(!$( "#"+ fragmentEntryLinkNamespace +"triggerBlurEvent").val() && $(this).parents(".hide").length == 0) {
			if (objectType == "date") {
				$( this ).parent().find(".govuk-date-input__input").trigger('blur');
			} else {
				$( this ).trigger('blur');
			}
		}

		let objectField = $( this ).attr('data-object-field');
		
		let objectValue = sanitize($( this ).val());
		
		if (objectType == "checkbox") {
			let checkboxValues = objectValue.split(",");
			body[objectField] = checkboxValues.map(str => str.trim());
		} else if (objectType == "file") {
			let fileData = $( this ).val();
			if (fileData) {
				let fileField = {};	
				fileData = fileData.substring(fileData.indexOf(',') + 1);
				fileField["fileBase64"] = fileData;
				fileField["name"] = this.dataset.fileName;
				body[objectField] = fileField;
			}
		} else if (objectType == "enquiryDocument" || objectType == "enquiryAddress") {
			//Do nothing
		} else if (objectType == "richText") {
			body[objectField] = $( this ).val();
		} else {
			body[objectField] = objectValue;
		}
	});

	if (thereAreNoHiddenErrors($(this))) {
		event.preventDefault();
		return false;
	}

	let restContextPath = $('#'+ fragmentEntryLinkNamespace +'restContextPath').val();
	let objectEntryId = $('#'+ fragmentEntryLinkNamespace +'objectEntryId').val();
	let objectDefinitionId = $('#'+ fragmentEntryLinkNamespace +'objectDefinitionId').val();
	let objectEntryERC = $('#'+ fragmentEntryLinkNamespace +'objectEntryERC').val();
	let scope = $('#'+ fragmentEntryLinkNamespace +'scope').val();
	let method = 'POST';

	let url = configuration.postEndpointURL;

	if(!url){
		url = '/o' + restContextPath;
		if (objectEntryId) {
			url = url + '/' + objectEntryId;
			method = 'PATCH';
		} else if (scope == 'site') {
			url = url + '/scopes/' + Liferay.ThemeDisplay.getScopeGroupId();
		}
	} else if(objectEntryERC) {
		url =  url.replace('{objectDefinitionId}', objectDefinitionId).replace('{objectEntryERC}', objectEntryERC);
		method = 'POST';
	}
	var buttonRedirectUrl = this.buttonRedirectUrl;
	var formContainer = $(this);
	
	(async () => {
		try {
			const response = await fetch(url, {
					headers: {
						"Content-Type": "application/json",
						"x-csrf-token": Liferay?.authToken || ''
					},
					method: method,
					body: JSON.stringify(body)
			});
		
			if (!response.ok) {
				throw new Error(`Network response was not ok: ${response.status}`);
			}
		
			const json = await response.json();
			const $this = $(this);
			const elements = $this.find('[data-event-post-object-creation]');
		
			const totalEvents = elements?.length || 0;
			console.debug(`data-event-post-object-creation events found: ${totalEvents}`);
		
			if (totalEvents > 0) {
				let promises = [];
		
				for (const element of Array.from(elements)) {
					// Fallback for CustomEvent support
					let event;
					try {
						event = new CustomEvent("postObjectEntryCreate", { detail: json });
					} catch (e) {
						event = document.createEvent('CustomEvent');
						event.initCustomEvent("postObjectEntryCreate", true, true, json);
					}
		
					let promise = new Promise((resolve) => {
						element.addEventListener("postObjectEntryCreateEventComplete", () => {
							console.debug("postObjectEntryCreateEventComplete");
							resolve();
						}, { once: true });
		
						element.dispatchEvent(event);
					});
					
					promises.push(promise);
				}
		
				Promise.all(promises).then(async (values) => { 
					console.debug("All postObjectEntryCreateEventComplete");
					
					if (configuration.afterPostEventsCompletedAction) {
						await executeObjectAction(objectDefinitionId, json.externalReferenceCode, configuration.afterPostEventsCompletedAction);	
					}
										
					processFormContainerPostCreationActions(buttonRedirectUrl, $(formContainer).attr('data-custom-events-redirect') || '', json); 
				});
		
			} else {
				processFormContainerPostCreationActions(buttonRedirectUrl, '', json);
			}
		
		} catch (error) {
		  console.error(error);
		  processFormContainerPostCreationActions(buttonRedirectUrl, '', json);
		}
	})();
	
	return false;

});

function processFormContainerPostCreationActions(buttonRedirectUrlValue, customEventsRedirect, json){
	var formContainerDefaultRedirectURL = buttonRedirectUrlValue ? buttonRedirectUrlValue : $('#'+ fragmentEntryLinkNamespace +'redirectURL').val();
	
	var redirectUrl = customEventsRedirect ? customEventsRedirect : formContainerDefaultRedirectURL;
	var paramCheck = redirectUrl.match(/\{([^}]+)\}/);

	if (paramCheck) {
		var paramName = paramCheck[1];
		const urlParams = new URLSearchParams(window.location.search);
		
		if (paramName === 'objectEntryId') {
			redirectUrl = redirectUrl.replace('{objectEntryId}', json.id);
		} else if (json[paramName]) {
			redirectUrl = redirectUrl.replace('{' + paramName +'}', json[paramName]);
		} else if (urlParams.has(paramName)) {
			redirectUrl = redirectUrl.replace('{' + paramName +'}', urlParams.get(paramName));
		}

		var propertyId = $('#'+ fragmentEntryLinkNamespace +'propertyId').val();
		if(redirectUrl.includes("propertyId")) {
			if (propertyId) {
				redirectUrl = redirectUrl.replace('{propertyId}', propertyId) 
			} else {
				redirectUrl = redirectUrl.replace('&propertyId={propertyId}', "") 
			}
		}
	}
	console.debug('redirectUrl: ' + redirectUrl);

	if (configuration.closePopupOnSave){
		parent.closePopup(json.id);
	} else if (configuration.isRedirectEnabled && redirectUrl) {
		window.location.href = redirectUrl;
	} else {
		//Hide pages
		$('.form-container-page').addClass('hide');
		
		//Replace placeholders
		let confBody = $('.form-confirmation-page').html();
		
		confBody = confBody.replaceAll('{objectEntryId}', json.id);
		
		Object.keys(json).forEach(function(key) {
			confBody = confBody.replaceAll('{' + key + '}', json[key]);
		});
		
		console.debug(confBody);
		
		$('.form-confirmation-page').html(confBody);
		
		//Display confirmation page
		$('.form-confirmation-page').removeClass('hide');
	}
}

function sanitize(string) {
	const map = {
	  '&': '&amp;',
		'<': '&lt;',
		'>': '&gt;',
		'"': '&quot;',
		"'": '&#39;',
		'/': '&#x2F;',
		'`': '&#x60;',
		'=': '&#x3D;'
	};
	const reg = /[&<>"'/]/ig;
	return string.replace(reg, (match)=>(map[match]));
}


$( "#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-next-button" ).on( "click", function( event ) {
	var dataObjectFields = document.querySelectorAll('[data-object-field]:not(.dp-hidden-field)');

	for (let dataObjectField of dataObjectFields) {
		let objectFieldName = dataObjectField.dataset.objectField;
		if (objectFieldName) {
			let objectFieldValue = dataObjectField.value;

			try {
				window[objectFieldName] = objectFieldValue.replace(/(\r\n|\n|\r)/gm, "");
			}
			catch (e) {
				console.error("Error when evalueting field:" + objectFieldName + ", with value: " + objectFieldValue + ". Error: " + e)
				event.preventDefault();
			}
		}
	}

	$(this).parent().find('[data-object-field]').each(function( index ) {
		if ($(this).parents(".hide").length == 0) {
			$(this).trigger('blur');
		}
	});

	$(this).parent().find('.govuk-date-input__input.date-form-field').each(function( index ) {
		if ($(this).parents(".hide").length == 0) {
			$(this).trigger('blur');
		}
	});

	if (thereAreNoHiddenErrors($(this).parent())) {
		event.preventDefault();
		return;
	}

	let page = $(this).closest('.form-container-page');
	let nextPageId = $(page).data("redirect-page");

	if (!nextPageId) {
		$(this).parent().find('.page-rule-fragment').each(function () {
			var $dataObjectField = $(this);

			var expressionValue = $dataObjectField.find('input[name$="expression"]').val();
			var targetPage = $dataObjectField.find('input[name$="targetPage"]').val();

			if (expressionValue && targetPage && eval(expressionValue)) {
				nextPageId = targetPage;
				return;
			}
		});
	}
	else {
		$(page).removeAttr("data-redirect-page");
	}

	if (nextPageId) {
		$('.form-container-page').addClass('hide');
		let nextPage = $('.form-container-page[data-page-name="' + nextPageId + '"]');
		if (nextPage.length == 0) {
			nextPage = $('.form-container-page[data-form-page="' + nextPageId + '"]');
		}

		$(nextPage).removeClass('hide');
		$(nextPage)[0].scrollIntoView();
	}
	else {
		let getNextItem = false;
		let formContainer = $(this).parent();
		$(this).closest(".dp-form-container").find(".form-container-page").each(function (index, item) {
			if ($(item).attr("id") === $(formContainer).attr("id")) {
				getNextItem = true;
			}
			else if (getNextItem) {
				$(formContainer).addClass('hide');
				$(item).removeClass('hide');
				$(item)[0].scrollIntoView();

				return false;
			}
		});
	}

	backNavigationHistory.push("#" + $(this).closest('.form-container-page').attr("id"));

	event.preventDefault();
});

$( "#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-back-link" ).on( "click", function( event ) {
	if(backNavigationHistory.length > 0) {
		let prevPageSelector = backNavigationHistory.pop();

		$('.form-container-page').addClass('hide');
		$(prevPageSelector).removeClass('hide');
	}

	event.preventDefault();
});

let itemsWithoutDataPageName = 0;
$("#"+ fragmentEntryLinkNamespace +"db-form-container .form-container-page").each(function(index) {
	if (document.body.classList.contains('has-edit-mode-menu')) {
		return;
	}

	if(!$(this).attr('data-page-name')) {
		$(this).attr('data-form-page', itemsWithoutDataPageName++);
	}

	if (index === 0) {
		$(this).find('.form-container-back-link').addClass('hide');
	}
	if (index > 0) {
		$(this).addClass('hide');
	}
});

$( "#"+ fragmentEntryLinkNamespace +"object-definition-select" ).on( "change", function( event ) {

	Liferay.Service(
	'/expandovalue/add-value',
		{
			companyId: Liferay.ThemeDisplay.getCompanyId(),
			className: 'com.liferay.portal.kernel.model.Layout',
			tableName: 'CUSTOM_FIELDS',
			columnName: 'objectDefinitionId',
			classPK: Liferay.ThemeDisplay.getPlid(),
			data: this.value
		},
		function(obj) {
			console.debug(obj);
			location.reload();
		}
	);
});

async function executeObjectAction(objectDefinitionId, objectEntryErc, actionName) {
	const url = `/o/dp-headless-object/v1.0/execute-object-action/${objectDefinitionId}/${actionName}/${objectEntryErc}`;

	try {
		const response = await fetch(url, {
			headers: {
				"Content-Type": "application/json",
				"x-csrf-token": Liferay.authToken
			},
			body: "{}",
			method: "POST"
		});

		if (!response.ok) {
			throw new Error(`Failed to execute action ${actionName} on object ${objectEntryErc}: ${response.status}`);
		}

	} catch (error) {
		console.error('Error executing action: ', error);
	}
}

$(document).ready(function () {
	let form = $("#" + fragmentEntryLinkNamespace + "db-form-container");
	if (form) {
		let formId = $(form).attr("id");
		registerLiferayForm(formId);
		preventFormSubmissionOnEnterPress(formId);
	}
});


(function () {

    function decodeHtmlEntities(text) {
        if (!text) return "";
        const txt = document.createElement("textarea");
        txt.innerHTML = text;
        return txt.value;
    }

    const loadJsPDF = () => {
        return new Promise((resolve) => {
            if (window.jspdf) {
                resolve();
                return;
            }
            const script = document.createElement("script");
            script.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
            script.onload = resolve;
            document.head.appendChild(script);
        });
    };

    async function downloadApplicationPDF() {
        try {
            await loadJsPDF();

            const { jsPDF } = window.jspdf;

            const referenceIdEl = document.querySelector(".reference-id");
            if (!referenceIdEl) {
                alert("Reference ID not available");
                return;
            }

            const referenceId = decodeHtmlEntities(referenceIdEl.innerText.trim());

            const pdf = new jsPDF("p", "mm", "a4");

            let y = 20;
            pdf.setFontSize(18);
            pdf.text("Application Confirmation", 105, y, { align: "center" });
            y += 15;

            pdf.setFontSize(11);
            pdf.text(`Reference ID: ${referenceId}`, 20, y);
            y += 10;

            pdf.text(`Submitted Date: ${new Date().toLocaleString()}`, 20, y);
            y += 15;

            pdf.text("Application submitted successfully", 20, y);
            y += 8;

            pdf.text("Please keep this Reference ID for tracking", 20, y);

            pdf.save(`Application_${referenceId}.pdf`);

        } catch (e) {
            console.error("PDF download failed:", e);
            alert("Failed to generate PDF");
        }
    }

    document.addEventListener("click", function (e) {
        if (e.target && e.target.id === "downloadPdfBtn") {
            downloadApplicationPDF();
        }
    });

})();
