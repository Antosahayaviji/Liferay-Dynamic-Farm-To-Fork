const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getSiteGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const buyerURL =
  portalURL + "/o/c/ffbuyers?groupId=" + groupId + "&pageSize=0";

const requiredContainer = document.getElementById("requiredProductList");

if (requiredContainer) {
  fetchBuyerRequests();
}
async function fetchBuyerRequests() {
  try {
    const response = await fetch(buyerURL, {
      method: "GET",
      headers: {
        "Authorization": authHeader,
        "Accept": "application/json"
      }
    });

    if (!response.ok) {
      throw new Error("HTTP " + response.status);
    }

    const data = await response.json();

    if (!data.items || data.items.length === 0) {
      requiredContainer.innerHTML =
        "<div class='no-data'>No Buyer Requests</div>";
      return;
    }

    renderBuyerRequests(data.items);

  } catch (error) {
    console.error("Buyer Fetch Error:", error);
  }
}

function renderBuyerRequests(items) {
  requiredContainer.innerHTML = "";

  items.forEach(function(item) {

    const productName =
      item.productRequired?.name || "Product";

    const quantity =
      item.requiredQuantity || "0 kg";

    const buyerName =
      item.buyerName || "";

    const acceptKey =
      item.extraQuantityAccept &&
      typeof item.extraQuantityAccept === "object"
        ? item.extraQuantityAccept.key
        : null;

    const isYes = acceptKey === "yes";

    const badgeClass = isYes
      ? "accept-yes"
      : "accept-no";

    const badgeText = isYes ? "Yes" : "No";

    const row = document.createElement("div");
    row.className = "request-row";

    row.innerHTML = `
      <div>
        <div class="product-name">${productName}</div>
        <div class="product-sub">${buyerName}</div>
      </div>

      <div class="quantity">${quantity}</div>

      <div>
        <span class="accept-pill ${badgeClass}">
          ${badgeText}
        </span>
      </div>
    `;

    requiredContainer.appendChild(row);
  });
}