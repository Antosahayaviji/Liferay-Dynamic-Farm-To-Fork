const portalURL = Liferay.ThemeDisplay.getPortalURL();
const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const traderEndpoint = `${portalURL}/o/c/fftraders?pageSize=0`;

async function loadAdminKPIs() {

    try {

        const response = await fetch(traderEndpoint, {
            headers: {
                "Content-Type": "application/json",
                "Authorization": authHeader
            }
        });

        if (!response.ok) {
            throw new Error("API Error: " + response.status);
        }

        const data = await response.json();
        const items = data.items || [];

        const totalTraders = data.totalCount || 0;

        let approvedCount = 0;
        let deniedCount = 0;

        items.forEach(item => {
            if (item.status?.code === 0) approvedCount++;
            if (item.status?.code === 4) deniedCount++;
        });

        document.getElementById("totalTraders").innerText = totalTraders;
        document.getElementById("approvedTraders").innerText = approvedCount;
        document.getElementById("deniedTraders").innerText = deniedCount;

    } catch (error) {
        console.error("KPI Load Error:", error);
    }

}

loadAdminKPIs();