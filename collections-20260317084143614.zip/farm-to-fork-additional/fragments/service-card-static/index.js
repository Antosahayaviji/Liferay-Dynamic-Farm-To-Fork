const serviceData = [
    { role: "Farmer", link: "/web/farm-to-fork/about-farmer" },
    { role: "Buyer", link: "/web/farm-to-fork/about-buyer" },
    { role: "Trader", link: "/web/farm-to-fork/about-trader" },
    { role: "Transport", link: "/web/farm-to-fork/about-transport" }
];

const renderServices = async () => {

    console.log("Rendering Farm to Fork Service Cards");

    const container = document.getElementById("ftfServiceContainer");

    container.innerHTML = "";

    serviceData.forEach(service => {

        const card = document.createElement("div");
        card.className = "ftf-card";

        card.innerHTML = `
            <div class="ftf-card-header">
                <h2>${service.role}</h2>
            </div>

            <div class="ftf-card-content">
                <p><strong>Service Category:</strong> Commercial Category</p>
                <p><strong>Service Focus:</strong> Farm to Fork Distribution</p>
            </div>

            <button class="ftf-apply-btn" data-link="${service.link}">
                Apply Now
            </button>
        `;

        container.appendChild(card);
    });

    attachButtonEvents();
};

const attachButtonEvents = () => {

    const buttons = document.querySelectorAll(".ftf-apply-btn");

    buttons.forEach(button => {

        button.addEventListener("click", function () {

            const url = this.getAttribute("data-link");

            console.log("Opening Form:", url);

            window.location.href = url;

        });

    });

};

renderServices();