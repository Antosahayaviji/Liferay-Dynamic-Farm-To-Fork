const portalURL = Liferay.ThemeDisplay.getPortalURL();
const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const farmersAPI = `${portalURL}/o/c/fffarmers?pageSize=200`;
const tradersAPI = `${portalURL}/o/c/fftraders?pageSize=200`;
const buyersAPI = `${portalURL}/o/c/ffbuyers?pageSize=200`;

async function fetchData(url) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      "Authorization": authHeader
    }
  });
  return response.json();
}

async function loadMonitoring() {

  const farmers = await fetchData(farmersAPI);
  const traders = await fetchData(tradersAPI);
  const buyers = await fetchData(buyersAPI);

  const totalFarmers = farmers.totalCount || 0;
  const harvestReady = traders.totalCount || 0;
  const buyerDemand = buyers.totalCount || 0;

  document.getElementById("totalFarmers").innerText = totalFarmers;

  const harvestPercent = (harvestReady/(totalFarmers||1))*100;
  const buyerPercent = (buyerDemand/(totalFarmers||1))*100;

  document.getElementById("harvestBar").style.width = harvestPercent+"%";
  document.getElementById("harvestDot").style.left = harvestPercent+"%";

  document.getElementById("buyerBar").style.width = buyerPercent+"%";
  document.getElementById("buyerDot").style.left = buyerPercent+"%";

  createDonut(harvestReady, buyerDemand);
}

function createDonut(greenValue, orangeValue){

  const redValue = Math.max(greenValue - orangeValue, 0);
  const total = greenValue + orangeValue + redValue;

  const greenPercent = total?Math.round((greenValue/total)*100):0;
  const orangePercent = total?Math.round((redValue/total)*100):0;

  document.getElementById("greenValue").innerText = greenValue;
  document.getElementById("greenPercent").innerText = `(${greenPercent}%)`;

  document.getElementById("orangeValue").innerText = redValue;
  document.getElementById("orangePercent").innerText = `(${orangePercent}%)`;

  document.getElementById("donutCenter").innerHTML =
    `<div class="green-text">${greenValue} (${greenPercent}%)</div>
     <div class="donut-divider"></div>
     <div class="red-text">${redValue} (${orangePercent}%)</div>`;

  const ctx = document.getElementById("donutChart");

  new Chart(ctx,{
    type:"doughnut",
    data:{
      datasets:[{
        data:[greenValue, redValue, orangeValue],
        backgroundColor:["#4caf50","#ef5350","#f9a825"],
        borderWidth:3,
        borderColor:"#fff"
      }]
    },
    options:{
      cutout:"70%",
      plugins:{legend:{display:false}}
    }
  });
}

loadMonitoring();