const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getScopeGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const demandList = document.getElementById("demandList");

const extractNumber = (value) => {
    if (!value) return 0;
    return parseInt(String(value).replace(/[^\d]/g, "")) || 0;
};

const formatKg = (value) => {
    return value.toLocaleString() + " kg";
};

const fetchData = async (endpoint) => {

    const apiURL = `${portalURL}/o/c/${endpoint}?groupId=${groupId}&pageSize=0`;

    const response = await fetch(apiURL, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": authHeader
        }
    });

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
};

const buildDemandVsSupply = async () => {

    try {

        const farmersData = await fetchData("fffarmers");
        const buyersData = await fetchData("ffbuyers");

        const farmers = farmersData.items || [];
        const buyers = buyersData.items || [];

        const totalReadySupply = farmers
            .filter(f => f.cropStatus?.key === "readyForHarvest")
            .reduce((sum, f) => sum + extractNumber(f.cropsReadyForHarvest), 0);

        renderDemand(buyers, totalReadySupply);

    } catch (error) {
        console.error("Demand vs Supply Error:", error);
    }
};

const renderDemand = (buyers, totalSupply) => {

    demandList.innerHTML = "";

    buyers.forEach(buyer => {

        const buyerName = buyer.buyerName || "Buyer";
        const demand = extractNumber(buyer.requiredQuantity);

        const gap = totalSupply - demand;
        const isSurplus = gap >= 0;

        const row = document.createElement("div");
        row.className = "demand-row";

        row.innerHTML = `
            <div class="buyer-name">${buyerName}</div>
            <div class="demand-value">${formatKg(demand)}</div>
            <div class="amount-badge ${isSurplus ? "surplus" : "shortage"}">
                ${isSurplus
                    ? formatKg(gap)
                    : "+" + formatKg(Math.abs(gap))}
            </div>
        `;

        demandList.appendChild(row);
    });
};

buildDemandVsSupply();