window[fragmentEntryLinkNamespace + 'showSelectionMenu'] = function() {
	$("#" + fragmentEntryLinkNamespace + "object-field-select").removeClass("hide");
}

$('#'+ fragmentEntryLinkNamespace +'select-field').on('change', function() {
  $('#' + fragmentEntryLinkNamespace + 'select-value').val(this.value);
	$('#' + fragmentEntryLinkNamespace + 'select-value').trigger("change");
});

Liferay.on('allPortletsReady', function () {
	$("#" + fragmentEntryLinkNamespace + "object-field-select").on("change", function() {
		const objectFieldConfigurationLabel = "Object field";
		const label = $("label:contains('" + objectFieldConfigurationLabel + "')").filter(function() {
			return $(this).text().trim() === objectFieldConfigurationLabel;
		});
		const inputId = label.attr('for');
		const inputField = document.getElementById(inputId);
		DP4LS.Objects.Utils.setConfigurationFieldValue(inputField, $(this).val());
	});
	
	$('[data-object-field]').on("change", function () {
		
		var dataObjectFields = document.querySelectorAll('[data-object-field]');
		const context = {};
		for (let dataObjectField of dataObjectFields) {
			let objectFieldName = dataObjectField.dataset.objectField;
			if (objectFieldName) {
				let objectFieldValue = dataObjectField.value;
				context[objectFieldName] = objectFieldValue.replace(/(\r\n|\n|\r)/gm, "");
			}
		}
		
		let hidden = false;
		if (configuration.fieldVisibility) {
			const fn = new Function(...Object.keys(context), `return !(${configuration.fieldVisibility})`);
			hidden = fn(...Object.values(context));
		}
		
		if (hidden) {
			$('#' + fragmentEntryLinkNamespace + 'select-wrapper').addClass('hide');
		} else {
			$('#' + fragmentEntryLinkNamespace + 'select-wrapper').removeClass('hide');
		}
	});
});

$('#' + fragmentEntryLinkNamespace + 'select-value, #' + fragmentEntryLinkNamespace + 'select-wrapper .govuk-select').on('blur',function(e){
	if(configuration.isRequired && $(this).closest(".hide").length === 0) {
		let value = $('#' + fragmentEntryLinkNamespace + 'select-value').val();
		if (!value || value === "null") {
			$('#' + fragmentEntryLinkNamespace + 'select-wrapper').addClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'select-error').removeClass('hide');
		} else {
			$('#' + fragmentEntryLinkNamespace + 'select-wrapper').removeClass('govuk-form-group--error');
			$('#' + fragmentEntryLinkNamespace + 'select-error').addClass('hide');
		}
	}
});


(function () {
    try {
        const wrapperId = fragmentEntryLinkNamespace + 'select-wrapper';
        const wrapper = document.getElementById(wrapperId);
        if (!wrapper) return;

        const selectEl = wrapper.querySelector('select');
        if (!selectEl) return;

        selectEl.style.setProperty('width', '100%', 'important');
        selectEl.style.setProperty('max-width', '100%', 'important');
        selectEl.style.setProperty('min-width', '100%', 'important');
        selectEl.style.setProperty('inline-size', '100%', 'important');
        selectEl.style.boxSizing = 'border-box';

        
        selectEl.style.setProperty('background-color', '#ffffff', 'important');
        selectEl.style.setProperty('border', '1px solid #dfe1e5', 'important');
        selectEl.style.setProperty('border-radius', '8px', 'important');
        selectEl.style.setProperty('height', '40px', 'important');
        selectEl.style.setProperty('padding', '8px 40px 8px 12px', 'important');
        selectEl.style.setProperty('font-size', '14px', 'important');
        selectEl.style.setProperty('line-height', '1.5', 'important');
        selectEl.style.setProperty('color', '#212529', 'important');
        selectEl.style.setProperty('box-shadow', 'none', 'important');

        selectEl.addEventListener('focus', function () {
            selectEl.style.setProperty('border-color', '#0b5fff', 'important');
            selectEl.style.setProperty(
                'box-shadow',
                '0 0 0 3px rgba(11, 95, 255, 0.15)',
                'important'
            );
        });

        selectEl.addEventListener('blur', function () {
            selectEl.style.setProperty('border-color', '#dfe1e5', 'important');
            selectEl.style.setProperty('box-shadow', 'none', 'important');
        });

    } catch (e) {
        console.error('Select box-model fix failed:', e);
    }
})();
