const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getSiteGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const transportURL =
  portalURL + "/o/c/fftransports?groupId=" + groupId + "&pageSize=0";

console.log("Transport API URL:", transportURL);

const transportContainer = document.getElementById("transportTrackingList");

if (!transportContainer) {
  console.error("Container transportTrackingList not found");
} else {
  fetchTransportData();
}

async function fetchTransportData() {
  try {
    const response = await fetch(transportURL, {
      method: "GET",
      headers: {
        "Authorization": authHeader,
        "Content-Type": "application/json"
      }
    });

    console.log("Transport Response Status:", response.status);

    const data = await response.json();
    console.log("Transport Full API Response:", data);

    if (!data.items || data.items.length === 0) {
      transportContainer.innerHTML =
        "<div class='no-data'>No Transport Records Found</div>";
      console.log("No items in API");
      return;
    }

    renderTransport(data.items);

  } catch (error) {
    console.error("Transport Fetch Error:", error);
  }
}

function renderTransport(items) {
  transportContainer.innerHTML = "";

  items.forEach(function(item) {

    console.log("Single Transport Record:", item);

    const companyName = item.transportCompanyName || "-";
    const fromPlace = item.fromPlace || "-";
    const toPlace = item.toPlace || "-";

    let statusName = "-";

    if (item.deliveryStatus && item.deliveryStatus.name) {
      statusName = item.deliveryStatus.name;
    }

    const statusClass =
      statusName.toLowerCase() === "delayed"
        ? "status-delayed"
        : "status-ontime";

    const row = document.createElement("div");
    row.className = "transport-row";

    row.innerHTML = `
      <div class="transport-name">${companyName}</div>
      <div class="transport-from">${fromPlace}</div>
      <div class="transport-to">${toPlace}</div>
      <div class="transport-status ${statusClass}">${statusName}</div>
    `;

    transportContainer.appendChild(row);
  });

  console.log("Rendered Rows:", items.length);
}