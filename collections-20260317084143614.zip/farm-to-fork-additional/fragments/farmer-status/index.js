const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getScopeGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const farmersContainer = document.getElementById("farmersSection");

console.log("Farmers Section Loading...");

const extractNumber = (value) => {
    if (!value) return 0;
    return parseInt(String(value).replace(/[^\d]/g, "")) || 0;
};

const formatKg = (value) => {
    return value.toLocaleString() + " kg";
};


const fetchFarmers = async () => {

    const apiURL = `${portalURL}/o/c/fffarmers?groupId=${groupId}&pageSize=0`;

    console.log("Calling API:", apiURL);

    const response = await fetch(apiURL, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": authHeader
        }
    });

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
};


const getStatusClass = (key) => {
    if (key === "readyForHarvest") return "status-ready";
    if (key === "growing") return "status-growing";
    if (key === "harvested") return "status-harvested";
    return "status-growing";
};

const getFertClass = (key) => {
    if (key === "yes") return "fert-yes";
    if (key === "needed") return "fert-needed";
    if (key === "no") return "fert-no";
    return "fert-no";
};


const renderFarmers = (farmers) => {

    if (!farmersContainer) {
        console.error("farmersSection not found");
        return;
    }

    farmersContainer.innerHTML = "";

    farmers.forEach(farmer => {

        const farmerName = farmer.farmerName || farmer.name || "Farmer";
        const cropName = farmer.cropName || "Crop";

        const statusKey = farmer.cropStatus?.key || "";
        const statusLabel = farmer.cropStatus?.name || "Unknown";

        const fertKey = farmer.fertilizerRequired?.key || "";
        const fertLabel = farmer.fertilizerRequired?.name || "No";

        const quantity = extractNumber(farmer.cropsReadyForHarvest);
        const quantityFormatted = formatKg(quantity);
        const tons = Math.floor(quantity / 1000);

        const row = document.createElement("div");
        row.className = "farmer-row";

        row.innerHTML = `
          
            <div class="farmer-left">
                <div class="farmer-icon">
                    <i class="fas fa-user"></i>
                </div>
                <div class="farmer-info">
                    <div class="farmer-name">${farmerName}</div>
                    <div class="crop-name">${cropName}</div>
                </div>
            </div>

            <div class="status-column">
                <div class="status-badge ${getStatusClass(statusKey)}">
                    ${statusLabel}
                </div>
            </div>

            <div class="farmer-middle">
                <div class="fertilizer-wrapper">
                    <div class="fertilizer-badge ${getFertClass(fertKey)}">
                        ${fertLabel}
                    </div>
                    <div class="fertilizer-text">
                        Fertilizer Needed
                    </div>
                </div>
            </div>


            <div class="farmer-right">
                <div class="quantity">${quantityFormatted}</div>
                <div class="sub-text">
                    ${statusLabel}, ${tons} Tons
                </div>
            </div>
        `;

        farmersContainer.appendChild(row);
    });

    console.log("Farmers Section Rendered:", farmers.length);
};


const initFarmersSection = async () => {
    try {
        const farmersData = await fetchFarmers();
        const farmers = farmersData.items || [];
        renderFarmers(farmers);
    } catch (error) {
        console.error("Farmers Section Error:", error);
    }
};



initFarmersSection();