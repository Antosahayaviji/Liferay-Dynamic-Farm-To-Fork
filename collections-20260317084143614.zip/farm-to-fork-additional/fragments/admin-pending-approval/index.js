const portalURL = Liferay.ThemeDisplay.getPortalURL();
const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const tradersAPI   = `${portalURL}/o/c/fftraders?pageSize=0`;
const buyersAPI    = `${portalURL}/o/c/ffbuyers?pageSize=0`;
const transportAPI = `${portalURL}/o/c/fftransports?pageSize=0`;

async function fetchData(url) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      "Authorization": authHeader
    }
  });

  if (!response.ok) {
    console.error("API Error:", url, response.status);
    return { items: [] };
  }

  return response.json();
}

function getTimeAgo(dateString) {
  if (!dateString) return "";
  const created = new Date(dateString);
  const now = new Date();
  const diffMs = now - created;
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 60) return diffMins + " mins";
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return diffHours + " hrs";
  const diffDays = Math.floor(diffHours / 24);
  return diffDays + " days";
}

async function loadPendingApprovals() {

  const traders   = await fetchData(tradersAPI);
  const buyers    = await fetchData(buyersAPI);
  const transport = await fetchData(transportAPI);

  const pendingList = document.getElementById("pendingList");
  pendingList.innerHTML = "";

  const allPending = [];

  traders.items.forEach(item => {
    if (item.status?.code !== 0) {
      allPending.push({
        name: item.traderName || "Trader",
        date: item.dateCreated
      });
    }
  });

  buyers.items.forEach(item => {
    if (item.status?.code !== 0) {
      allPending.push({
        name: item.buyerName || "Buyer",
        date: item.dateCreated
      });
    }
  });

  transport.items.forEach(item => {
    if (item.status?.code !== 0) {
      allPending.push({
        name: item.transportCompanyName || "Transport",
        date: item.dateCreated
      });
    }
  });

  allPending.sort((a, b) => new Date(b.date) - new Date(a.date));

  allPending.slice(0, 5).forEach(entry => {

    const timeAgo = getTimeAgo(entry.date);

    const itemHTML = `
      <div class="pending-item">
        <div class="pending-info">
          <div class="pending-name">${entry.name}</div>
          <div class="pending-meta">Pending • ${timeAgo}</div>
        </div>
        <button class="review-btn">Review</button>
      </div>
    `;

    pendingList.innerHTML += itemHTML;
  });

}

loadPendingApprovals();