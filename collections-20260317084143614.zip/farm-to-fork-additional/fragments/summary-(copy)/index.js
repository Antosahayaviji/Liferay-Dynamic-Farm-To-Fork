const isAddressChildFieldWrapper = function (wrapperId) {
	return wrapperId.match(/(\w*)address-(\w+)-wrapper/g);
};

const getInputFieldLabel = function (element) {
	let label = '';
	let parentFormGroup = $(element).parents(".govuk-form-group").first();
	let parentFormGroupId = $(parentFormGroup).attr("id");

	if ($(element).attr("type") === "file") {
		const hiddenInput = $(parentFormGroup)
			.find("input[type='hidden'][data-object-field]");
		if (hiddenInput.length > 0) {
			return hiddenInput.attr("data-object-field");
		}
	}

	if (configuration.useDefaultObjectFieldLabel) {
		label = $(element).attr("data-object-field-label");
	}

	if (!label) {
		if (parentFormGroupId) {
			if (parentFormGroupId.endsWith("address-lookup-wrapper")) {
				label = $(parentFormGroup)
					.find("label[data-lfr-editable-id]")
					.html();
			} else if (parentFormGroupId.endsWith("radio-wrapper")) {
				label = $(parentFormGroup).find("legend").html();
			} else if (parentFormGroupId.endsWith("checkbox-wrapper")) {
				label = $(parentFormGroup).find("legend").html();
			} else if (
				parentFormGroupId.endsWith("text-input-wrapper") ||
				isAddressChildFieldWrapper(parentFormGroupId) ||
				parentFormGroupId.endsWith("select-wrapper") ||
				parentFormGroupId.endsWith("textarea-wrapper") ||
				parentFormGroupId.endsWith("date-wrapper")
			) {
				label = $(parentFormGroup).find("label").html();
			}
		}
	}

	return label || "unsupported-field";
};

$(document).ready(function () {

	let inputFields = [];
	let fieldNames = [];
	let fieldsFromConfig = configuration.fieldsList || '';

	if (fieldsFromConfig.length > 0) {
		fieldNames = fieldsFromConfig.split(',');
		for (const element of fieldNames) {
			let field = $('[data-object-field="' + element + '"]');
			inputFields.push(field);
		}
	} else {
		inputFields = $('[data-object-field]');
		inputFields = inputFields.add("input[type='file']");
	}

	let fieldSummaryObjects = [];

	for (const element of inputFields) {

		if (
			$(element).attr("type") === "hidden" &&
			$(element).attr("data-object-type") === "file"
		) {
			continue;
		}

		let parentFormGroup = $(element).parents(".govuk-form-group").first();
		let parentFormGroupId = $(parentFormGroup).attr("id");

		let value = $(element).val();

		if ($(element).attr("type") === "file") {
			value = element.files && element.files.length > 0
				? element.files[0].name
				: '';
		}

		if (parentFormGroupId) {
			if (parentFormGroupId.endsWith("address-lookup-wrapper")) {
				if (!$(element).attr("id").endsWith("address-fullAddress")) {
					continue;
				}
			} else if (parentFormGroupId.endsWith("radio-wrapper")) {
				let checkedRadioInput =
					$(parentFormGroup).find(".govuk-radios__input:checked");
				value = checkedRadioInput
					.siblings(".govuk-radios__label")
					.text();
			} else if (parentFormGroupId.endsWith("checkbox-wrapper")) {
				// READ CHECKED CHECKBOX LABELS
				var checkedLabels = [];
				$(parentFormGroup).find('.govuk-checkboxes__input:checked').each(function() {
					checkedLabels.push($(this).closest('.govuk-checkboxes__item').find('label').text().trim());
				});
				value = checkedLabels.join(', ');
			} else if (parentFormGroupId.endsWith("select-wrapper")) {
				value = $(parentFormGroup)
					.find("option:selected")
					.html();
			}
		}

		const label = getInputFieldLabel(element);

		let pageElement = $(element).parents('.form-container-page').first();
		let page =
			$(pageElement).attr('data-form-page') ||
			$(pageElement).attr('data-page-name');

		fieldSummaryObjects.push({
			value: value,
			input: $(element),
			label: label,
			page: page
		});
	}

	let summaryContainer =
		$('#' + fragmentEntryLinkNamespace + 'dp-form-summary');

	for (const element of fieldSummaryObjects) {

		let rowClass = element.value ? "" : "hide";

		$(summaryContainer).append(
			"<div class='govuk-summary-list__row " + rowClass +
			"' data-input-id='" + $(element.input).attr('id') + "'>" +
				"<dt class='govuk-summary-list__key'>" + element.label + "</dt>" +
				"<dd class='govuk-summary-list__value'>" + element.value + "</dd>" +
				"<dd class='govuk-summary-list__actions'>" +
					"<a class='govuk-link page-switch-link' " +
					"data-page-to-link-to='" + element.page +
					"' href='javascript:;'>Change</a>" +
				"</dd>" +
			"</div>"
		);

		let summaryRow =
			$(summaryContainer).find(
				"[data-input-id='" + $(element.input).attr('id') + "']"
			);

		if ($(element.input).attr("type") === "file") {
			$(element.input).on("change", function (e) {
				let fileName =
					e.target.files && e.target.files.length > 0
						? e.target.files[0].name
						: '';
				$(summaryRow)
					.find(".govuk-summary-list__value")
					.html(fileName);

				fileName
					? $(summaryRow).removeClass("hide")
					: $(summaryRow).addClass("hide");
			});
		} else if ($(element.input).attr("data-object-type") === "checkbox") {
			// CHECKBOX - listen to hidden value change
			$(element.input).on("change", function () {
				var checkedLabels = [];
				var ns = $(this).attr('id').replace('checkbox-value', '');
				$('input[type=checkbox][name="' + ns + 'checkbox-option"]:checked').each(function() {
					checkedLabels.push($(this).closest('.govuk-checkboxes__item').find('label').text().trim());
				});
				var val = checkedLabels.join(', ');
				$(summaryRow).find(".govuk-summary-list__value").html(val);
				val
					? $(summaryRow).removeClass("hide")
					: $(summaryRow).addClass("hide");
			});
		} else {
			$(element.input).on("blur change", function () {
				let val = $(this).val();
				$(summaryRow)
					.find(".govuk-summary-list__value")
					.html(val);

				val
					? $(summaryRow).removeClass("hide")
					: $(summaryRow).addClass("hide");
			});
		}
	}
});

const getAllObjectFieldValues = function (dataObjectFieldName) {
	let value = '';
	$("[data-object-field='" + dataObjectFieldName + "']").each(function () {
		if ($(this).parents(".hide").length === 0) {
			if (
				$(this).attr("type") === "file" &&
				this.files.length > 0
			) {
				value += this.files[0].name + ",";
			} else if ($(this).val()) {
				value += $(this).val() + ",";
			}
		}
	});
	return value ? value.slice(0, -1) : '';
};

const formatDate = function (dateString) {
	try {
		return new Date(dateString).toLocaleDateString();
	} catch (e) {
		return '';
	}
};