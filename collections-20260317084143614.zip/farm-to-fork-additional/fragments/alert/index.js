const portalURL = Liferay.ThemeDisplay.getPortalURL();
const groupId = Liferay.ThemeDisplay.getScopeGroupId();

const username = "demo.admin@placecube.com";
const password = "Cubes2021";
const authHeader = "Basic " + btoa(username + ":" + password);

const alertsList = document.getElementById("alertsList");

console.log("Alerts Auto System Started");

const extractNumber = (value) => {
    if (!value) return 0;
    return parseInt(String(value).replace(/[^\d]/g, "")) || 0;
};

const fetchData = async (endpoint) => {

    const apiURL = `${portalURL}/o/c/${endpoint}?groupId=${groupId}&pageSize=0`;

    const response = await fetch(apiURL, {
        method: "GET",
        headers: {
            "Accept": "application/json",
            "Authorization": authHeader
        }
    });

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
};

const buildAlerts = async () => {

    try {

        const farmersData = await fetchData("fffarmers");
        const buyersData = await fetchData("ffbuyers");
        const tradersData = await fetchData("fftraders");
        const transportsData = await fetchData("fftransports");

        generateAlerts(
            farmersData.items || [],
            buyersData.items || [],
            tradersData.items || [],
            transportsData.items || []
        );

    } catch (error) {
        console.error("Alerts Error:", error);
    }
};

const generateAlerts = (farmers, buyers, traders, transports) => {

    alertsList.innerHTML = "";

    const alerts = [];

    const readyCount = farmers.filter(f =>
        f.cropStatus?.key === "readyForHarvest"
    ).length;

    if (readyCount > 0) {
        alerts.push({
            iconClass: "icon-green",
            icon: "fas fa-seedling",
            text: `${readyCount} crops are ready for harvest`
        });
    }

   
    const delayedCount = transports.filter(t =>
        t.deliveryStatus?.key === "delayed"
    ).length;

    if (delayedCount > 0) {
        alerts.push({
            iconClass: "icon-red",
            icon: "fas fa-truck",
            text: `${delayedCount} deliveries are delayed`
        });
    }

  
    const readySupply = farmers
        .filter(f => f.cropStatus?.key === "readyForHarvest")
        .reduce((sum, f) => sum + extractNumber(f.cropsReadyForHarvest), 0);

    const totalDemand = buyers
        .reduce((sum, b) => sum + extractNumber(b.requiredQuantity), 0);

    if (totalDemand > readySupply) {

        const gap = totalDemand - readySupply;

        alerts.push({
            iconClass: "icon-yellow",
            icon: "fas fa-exclamation",
            text: `Buyer demand exceeds supply by ${gap.toLocaleString()} kg`
        });
    }

    
    const pendingCount = traders.filter(t =>
        t.approvalStatus?.key === "pending"
    ).length;

    if (pendingCount > 0) {
        alerts.push({
            iconClass: "icon-blue",
            icon: "fas fa-file-alt",
            text: `${pendingCount} orders pending approval`
        });
    }

    
    alerts.slice(0, 4).forEach(alert => {
        createAlert(alert.iconClass, alert.icon, alert.text);
    });

    console.log("Rendered Alerts:", alerts.length);
};

const createAlert = (iconClass, icon, text) => {

    const item = document.createElement("div");
    item.className = "alert-item";

    item.innerHTML = `
        <div class="alert-icon ${iconClass}">
            <i class="${icon}"></i>
        </div>
        <div class="alert-content">
            <div class="alert-text">${text}</div>
            <div class="alert-time">Recently</div>
        </div>
        <div class="alert-dot dot-yellow"></div>
    `;

    alertsList.appendChild(item);
};


buildAlerts();
setInterval(buildAlerts, 20000);